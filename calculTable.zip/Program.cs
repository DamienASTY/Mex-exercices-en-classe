﻿using System;

namespace loop
{
    class Program
    {
        //ne fonctionne qu'avec des entiers positif !
        static void calculTable(int table, int nombreTour, out string sortieTable)
        {
            if(table > 0)
            {
                sortieTable = $"Calcul de la table de {table} : [ \n";
                for(int i =0; i < nombreTour + 1; i++)
                {
                    sortieTable += $"{table} * {i} = {table * i} \n";
                }
                sortieTable += " ]";
            }
            else
            {
                sortieTable = "Impossible d'effectuer la demande";
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Calculateur de table de multiplication");
            int table, tour; string sortieTable;
            Console.Write("Entrez la table -> ");
            table = int.Parse(Console.ReadLine());
            Console.Write("Entrez le nombre de tour -> ");
            tour = int.Parse(Console.ReadLine());
            calculTable(table, tour, out sortieTable);
            Console.WriteLine(sortieTable);
        }
    }
}
