﻿using System;

namespace dispatch
{
    class Program
    {
        static void attributionSport(int age, out string categori)
        {
            if (age > 5 || age <= 14)
            {
                if(age == 6 || age == 7)
                {
                    categori = "Poussin";
                }
                if(age >= 8 || age <= 9)
                {
                    categori = "Pupille";
                }
                if (age == 10 || age == 11)
                {
                    categori = "Minime";
                }
                if (age >= 12 || age <= 14)
                {
                    categori = "Cadet";
                }
                else
                {
                    categori = "Aucune catégorie n'éxiste pour vous";
                }
            }
            else
            {
                categori = "Aucune catégorie n'éxistep pour vous";
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Classeur");
            string categorie; int age;
            Console.Write("Donnez votre age -> ");
            age = int.Parse(Console.ReadLine());
            attributionSport(age, out categorie);
            Console.WriteLine(categorie);

        }
    }
}
